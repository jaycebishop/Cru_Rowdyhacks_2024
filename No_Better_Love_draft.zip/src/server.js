const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.get('/messages', (req, res) => {
    const messages = getMessages();
    res.json(messages);
});

app.post('/messages', (req, res) => {
    const newMessage = req.body;
    newMessage.id = generateUniqueId();

    const messages = getMessages();
    messages.push(newMessage);

    saveMessages(messages);

    res.json(newMessage);
});

function getMessages() {
    try {
        const data = fs.readFileSync('messages.json', 'utf8');
        return JSON.parse(data) || [];
    } catch (error) {
        return [];
    }
}

function saveMessages(messages) {
    const data = JSON.stringify(messages, null, 2);
    fs.writeFileSync('messages.json', data, 'utf8');
}

function generateUniqueId() {
    return new Date().getTime();
}

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
