document.addEventListener('DOMContentLoaded', function() {
    displayMessages();
});

function displayMessages() {
    const messageBoard = document.getElementById('message-board');
    messageBoard.innerHTML = '';

    const messages = getMessages();

    messages.forEach(message => {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message');

        const usernameParagraph = document.createElement('p');
        usernameParagraph.innerHTML = `<strong>${message.username}:</strong> ${message.text}`;
        messageDiv.appendChild(usernameParagraph);

        const timestampParagraph = document.createElement('p');
        timestampParagraph.classList.add('timestamp');
        timestampParagraph.textContent = message.timestamp;
        messageDiv.appendChild(timestampParagraph);

        messageBoard.appendChild(messageDiv);
    });
}

function getMessages() {
    const storedMessages = localStorage.getItem('messages');
    return storedMessages ? JSON.parse(storedMessages) : [];
}

function postMessage() {
    const usernameInput = document.getElementById('username');
    const messageInput = document.getElementById('message');

    const username = usernameInput.value;
    const message = messageInput.value;

    if (username && message) {
        const timestamp = new Date().toLocaleString();

        const newMessage = {
            username: username,
            text: message,
            timestamp: timestamp
        };

        const messages = getMessages();
        messages.push(newMessage);

        localStorage.setItem('messages', JSON.stringify(messages));

        // Clear input fields
        usernameInput.value = '';
        messageInput.value = '';

        // Refresh the display
        displayMessages();
    }
}



document.addEventListener('DOMContentLoaded', function() {
    displayMessages();
});

function displayMessages() {
    const messageBoard = document.getElementById('message-board');
    messageBoard.innerHTML = '';

    const messages = getMessages();

    messages.forEach(message => {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message');

        const usernameParagraph = document.createElement('p');
        usernameParagraph.innerHTML = `<strong>${message.username}:</strong> ${message.text}`;
        messageDiv.appendChild(usernameParagraph);

        if (message.replies && message.replies.length > 0) {
            const repliesList = document.createElement('ul');
            repliesList.classList.add('replies-list');

            message.replies.forEach(reply => {
                const replyItem = document.createElement('li');
                replyItem.innerHTML = `<strong>${reply.username}:</strong> ${reply.text}`;
                repliesList.appendChild(replyItem);
            });

            messageDiv.appendChild(repliesList);
        }

        const timestampParagraph = document.createElement('p');
        timestampParagraph.classList.add('timestamp');
        timestampParagraph.textContent = message.timestamp;
        messageDiv.appendChild(timestampParagraph);

        const replyForm = createReplyForm(message);
        messageDiv.appendChild(replyForm);

        messageBoard.appendChild(messageDiv);
    });
}

function createReplyForm(parentMessage) {
    const form = document.createElement('form');
    form.classList.add('reply-form');
    form.innerHTML = `
        <label for="reply-username">Your Username:</label>
        <input type="text" id="reply-username" required>
        <br>
        <label for="reply-message">Your Reply:</label>
        <textarea id="reply-message" rows="2" required></textarea>
        <br>
        <button type="button" onclick="postReply(${parentMessage.id})">Post Reply</button>
    `;
    return form;
}

function postReply(parentMessageId) {
    const replyUsernameInput = document.getElementById('reply-username');
    const replyMessageInput = document.getElementById('reply-message');

    const replyUsername = replyUsernameInput.value;
    const replyMessage = replyMessageInput.value;

    if (replyUsername && replyMessage) {
        const timestamp = new Date().toLocaleString();

        const newReply = {
            id: generateUniqueId(),
            username: replyUsername,
            text: replyMessage,
            timestamp: timestamp
        };

        const messages = getMessages();
        const parentMessage = messages.find(message => message.id === parentMessageId);

        if (!parentMessage.replies) {
            parentMessage.replies = [];
        }

        parentMessage.replies.push(newReply);

        localStorage.setItem('messages', JSON.stringify(messages));

        // Clear input fields
        replyUsernameInput.value = '';
        replyMessageInput.value = '';

        // Refresh the display
        displayMessages();
    }
}

function generateUniqueId() {
    return new Date().getTime(); // This is a simple example, in a real-world scenario, consider using a more robust method
}